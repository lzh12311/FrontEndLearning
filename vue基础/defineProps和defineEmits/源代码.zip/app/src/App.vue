<template>
  <div>
    <h1>订单状态：{{ status }}</h1>
    <Order :status="status" :data="orderData" @change="change" />
    <button @click="submit">提交订单</button>
  </div>
</template>

<script setup>
  import {
    ref,
    reactive,
    toRaw
  } from 'vue'
  import Order from './components/order.vue'
  const status = ref('未完成')
  const change = (val) => {
    status.value = val
  }

  const orderData = reactive([
    {
      name: 'iPhone 15 Pro Max',
      price: 9999,
      num: 1
    },
    {
      name: 'HUAWEI Mate 60 Pro+',
      price: 8999,
      num: 1
    }
  ])
  const submit = () => {
    console.log(toRaw(orderData))
  }
</script>
<style scoped>
.container {
  margin-top: 10px;
  background-color: #f5f5f5;
  padding:10px 20px;
}
.container-1 {
  background-color: #2f56c9;
}
</style>