<template>
  <div class="container">
    <button @click="pay">支付</button>
    <ul>
      <li v-for="(item, index) in props.data" :key="index">
        <label>{{ item.name }}</label>
        <div class="flex">
          <div>
            <label>价格：</label>
            <input type="text" :value="item.price">
          </div>
          <div class="flex">
            <label>数量：</label>
            <div class="flex">
              <button @click="handleChange('subtrace', item)">-</button>
              <p>{{ item.num }}</p>
              <button @click="handleChange('add', item)">+</button>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>
<script setup>
  const props = defineProps(['status', 'data'])
  const emits =  defineEmits(['change'])
  const pay = () => {
    // props.status = '已支付' 错误的
    emits('change', '已支付')
  }
  const handleChange = (type, item) => {
    if (type === 'subtrace') {
      item.num--
    } else {
      item.num++
    }
  }
</script>

<style scoped>
li {
  list-style: none;
}
.flex {
  display: flex;
}
.flex p {
  margin: 0;
  width: 40px;
  height: 20px;
  text-align: center;
}
ul button {
  width: 20px;
  height: 20px;
}
</style>
