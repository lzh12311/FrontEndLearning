<template>
    <div>
        <h1>{{ props.data }}</h1>
        <h3>{{ props.a }}</h3>
        <button @click="handleClick">子组件修改</button>
    </div>
</template>
<script setup>
const props = defineProps({
    a: Number,
    data: String
})
const emits = defineEmits(['change'])
const handleClick = () => {
    emits('change', '哈哈')
}
</script>