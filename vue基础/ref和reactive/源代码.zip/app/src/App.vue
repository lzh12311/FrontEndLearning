<template>
  <div>
    <button @click="change">点击</button>
    <div>{{data.name}}</div>
    <div>{{data.age}}</div>
  </div>
</template>

<script>
import {
  ref,
  reactive
} from 'vue'
export default {
  setup() {
    let data = ref({
      name: 'allen',
      age: 18
    })
    // console.log(name)
    // const data = reactive(1)
    // console.log(data)
    const change = () => {
      data.value = {
        name: 'jason',
        age: 18
      }
    }
    return {
      data,
      change
    }
  }
}
</script>