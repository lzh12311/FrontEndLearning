<template>
  <div>
    <p>{{ num }}</p>
    <p>{{ ml }}</p>
    <p>{{ person.name }}</p>
    <button @click="handleNum">修改公里数</button>
    <button @click="handleMl">修改燃油箱存量</button>
    <button @click="handleName">修改名称</button>
  </div>
</template>

<script setup>
  import {
    ref,
    reactive,
    watch,
    watchEffect
  } from 'vue'
  // 公里数
  const num = ref(0)
  // 燃油箱存量
  const ml = ref(50)
  const person = reactive({
    name: 'allen'
  })
  const handleNum = () => {
      num.value += 1000
  }
  const handleMl = () => {
      ml.value -= 10
  }
  const handleName = () => {
    person.name = 'jason'
  }
  // 注意：不能监听响应式对象
  watchEffect(() => {
      console.log('打印')
      if (ml.value < 10 || num.value > 5000) {
          alert('报警')
      }
  })
</script>
<style scoped>
.container {
  margin-top: 10px;
  background-color: #f5f5f5;
  padding:10px 20px;
}
</style>