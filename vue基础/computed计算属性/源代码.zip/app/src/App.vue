<template>
  <div>
    <div class="container">
      <label for="number">人民币：</label>
      <input type="number" v-model="inputNumber" />
      <p>美元：{{ dollar }} $</p>
      <p>日元：{{ yen }} ￥</p>
    </div>
    <div class="container">
      <div class v-for="(item, index) in reactiveData" :key="index">
      <p>数量：{{ item.num }} 个</p>
      <p>
        <label for="number">价格：</label>
        <input type="number" v-model="item.price" />
      </p>
      </div>
    </div>
    <p>总价：{{ total }}</p>
    <div class="container">
      <p>
        <label for="number">firstName：</label>
        <input v-model="firstName" />
      </p>
      <p>
        <label for="number">lastName：</label>
        <input v-model="lastName" />
      </p>
      <h1>{{ fullName }}</h1>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, reactive  } from 'vue'
const inputNumber = ref(0)
const dollar = computed(() => {
  return (inputNumber.value * 0.14).toFixed(2)
})
const yen = computed(() => {
  return (inputNumber.value * 20.56).toFixed(2)
})
// 商品列表数据
const reactiveData = reactive([{num: 1, price: 2}, {num: 2, price: 3}])
const total = computed(() => {
  return reactiveData.reduce((total, cur) => total + cur.num * cur.price, 0)
})
// 数据组装
const firstName = ref('San')
const lastName = ref('Zhang')
const fullName = computed(() => lastName.value + ' ' + firstName.value)
</script>
<style scoped>
.container {
  margin-top: 10px;
  background-color: #f5f5f5;
  padding:10px 20px;
}
.container-1 {
  background-color: #2f56c9;
}
</style>