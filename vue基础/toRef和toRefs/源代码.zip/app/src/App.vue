<template>
  <div>
    <div>{{ count }}</div>
    <div>{{ a.a1 }}</div>
    <button @click="handleChange">修改</button>
  </div>
</template>

<script setup>
import {
  ref,
  reactive,
  toRef,
  toRefs
} from 'vue'
// const data = {count: 1}
// let count = toRef(reactive(data), 'count')
// console.log(obj)

const data = {count: 1, a: { a1: 4}, b: 3}
const o = reactive(data)
console.log(toRefs(o))
const { count, a } = toRefs(o)

const handleChange = () => {
  // numberRef.value++
  // count++
  count.value++
  a.value.a1++
}
</script>