# vuex-cart-demo-template

## 1.Project setup
```
npm install
```

## 2. Server open

```
node server.js
```

## 3. http open

other bash

```
npm run serve
```

## 4. Compiles and minifies for production
```
npm run build
```

## 5. Lints and fixes files
```
npm run lint
```
