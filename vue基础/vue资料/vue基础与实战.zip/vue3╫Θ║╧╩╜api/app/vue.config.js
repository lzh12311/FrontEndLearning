module.exports = {
    lintOnSave: false
}