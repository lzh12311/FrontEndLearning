<template>
  <div id="app">
    <table>
      <thead>
        <th>商品名称</th>
        <th>单价</th>
        <th>数量</th>
        <th>总价</th>
      </thead>
      <tbody>
        <td>{{name}}</td>
        <td>
          <el-input
            placeholder="请输入内容"
            v-model="price"
            clearable>
          </el-input>
        </td>
        <td>
          <el-input-number
            v-model="num"
            :min="1"
            :max="10"
            label="描述文字">
          </el-input-number>
        </td>
        <!-- <td>{{ getTotolPrice() }}</td> -->
        <td>{{ getTotolPrice }}</td>  
      </tbody>
    </table>
    <el-button @click="handleClick">重置金额</el-button>
    <!-- <h1>{{ a }}</h1> -->
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      a: 1,
      name: 'Apple Watch series3 16G 午夜色',
      price: 638,
      num: 1
    }
  },
  methods: {
    handleClick() {
      this.getTotolPrice = 123
    }
  },
  computed: {
    // getTotolPrice() {
    //   return this.num * this.price
    // }
    getTotolPrice: {
      get() {
        return this.num * this.price
      },
      set(val) {
        this.price = val
        this.num = 1
      }
    }
  }
}
</script>

<style>
/* #app {
  margin: 0 auto;
  width: 645px;
} */
table {
  margin: 0 auto;
  border: 1px solid #000;
}
thead th {
  text-align: left;
}
tbody td {
  border: 1px solid #000;
}
tbody td:nth-child(1){
  width: 400px;
}
tbody td:nth-child(2){
  width: 200px;
}
tbody td:nth-child(3){
  width: 200px;
}
tbody td:nth-child(4){
  width: 200px;
}
</style>
