<template>
    <!-- blog组件 -->
    <div>
        <p>博文的标题</p>
        <div>
            <p>博文的内容</p>
            <slot>
                <h1>我是一名web讲师: kevin</h1>
            </slot>
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {}
    }
}
</script>