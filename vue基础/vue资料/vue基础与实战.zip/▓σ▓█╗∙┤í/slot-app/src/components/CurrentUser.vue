<template>
    <span>
        <slot v-bind:user="user">{{ user.lastName }}</slot>
    </span>
</template>
<script>
export default {
    data() {
        return {
            user: {
                firstName: '张',
                lastName: '三'
            }
        }
    }
}
</script>