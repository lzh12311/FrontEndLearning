<template>
    <!-- layout组件 -->
    <div class="container">
        <header>
            <!-- 页头放这里 -->
            <slot name="header"></slot>
        </header>
        <main>
            <!-- 主要内容放这里 -->
            <slot></slot>
        </main>
        <footer>
            <!-- 页脚放这里 -->
            <slot name="footer"></slot>
        </footer>
    </div>
</template>
<script>
export default {
    data() {
        return {}
    }
}
</script>