<template>
  <div id="app">
    <!-- <img alt="Vue logo" src="./assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <!-- <blog ref="blog"> -->
      <!-- 这里可以插入文案 -->
      <!-- 今天是一个好天气 -->
      <!-- 可以插入标签 -->
      <!-- <h1>我是一名web讲师: {{ teacher }}</h1> -->
      <!-- 也可以插入组件 -->
      <!-- <hello-world></hello-world> -->
      <!-- <template v-slot:defalut>
        <h1>我是一名web讲师: {{ teacher }}</h1>
      </template> -->
    <!-- </blog> -->
    <!-- <layout>
      <template v-slot:header>
        <div >我是头部内容</div>
      </template>
      
      <div>我是主要内容</div>
      <template v-slot:footer>
        <div>我是尾部内容</div>
      </template>
    </layout> -->

    <current-user>
      <template v-slot:default="props">
        {{ props.user.firstName }}
      </template>
    </current-user>
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
// import Blog from './components/Blog.vue'
// import Layout from './components/Layout.vue'
import CurrentUser from './components/CurrentUser.vue'
export default {
  name: 'App',
  components: {
    // HelloWorld,
    // Blog,
    // Layout,
    CurrentUser
  },
  data() {
    return {
      teacher: 'allen'
    }
  },
  mounted() {
    
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
