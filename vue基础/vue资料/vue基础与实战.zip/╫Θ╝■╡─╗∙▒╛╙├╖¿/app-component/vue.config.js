module.exports = {
    lintOnSave: false,
    runtimeCompiler: true
}