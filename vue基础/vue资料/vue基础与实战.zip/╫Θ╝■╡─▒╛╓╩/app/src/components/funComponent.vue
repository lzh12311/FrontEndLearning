<template functional>
    <div></div>
</template>