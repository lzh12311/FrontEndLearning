<template>
  <div>UserList page</div>
</template>
<script>
export default {
  name: 'list',
  data () {
    return {}
  }
}
</script>
<style scoped>
  div {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #00BFFF;
    height: 100vh;
    font-size: 100px;
    color: #fff;
  }
</style>