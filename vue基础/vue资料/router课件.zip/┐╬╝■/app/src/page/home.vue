<template>
  <div>Home page</div>
</template>
<script>
export default {
  name: 'home',
  data () {
    return {}
  }
}
</script>
<style scoped>
  div {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #FFA500;
    height: 100vh;
    font-size: 100px;
    color: #fff;
  }
</style>