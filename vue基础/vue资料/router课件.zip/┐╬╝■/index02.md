### vue-router使用流程

1. 下载vue-router依赖
2. 编写路由配置，全局注入router
3. 在vue实例上进行挂载
4. 使用router-view用于承载页面