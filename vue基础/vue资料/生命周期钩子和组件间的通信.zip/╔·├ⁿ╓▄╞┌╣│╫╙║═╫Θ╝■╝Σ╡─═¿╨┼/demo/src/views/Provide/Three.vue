<template>
  <div class="compc">
    <h5>this is C component</h5>
    <p>收到来自A组件的消息：</p>
  </div>
</template>
<script>
export default {
  name: "Compc"
};
</script>