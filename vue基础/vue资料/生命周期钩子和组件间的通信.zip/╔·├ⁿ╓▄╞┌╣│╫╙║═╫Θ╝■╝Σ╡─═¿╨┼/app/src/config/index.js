export default {
  title: 'admin',
  baseUrl: {
    // 开发环境
    dev: '/api/',
    pro: ''
  }
}