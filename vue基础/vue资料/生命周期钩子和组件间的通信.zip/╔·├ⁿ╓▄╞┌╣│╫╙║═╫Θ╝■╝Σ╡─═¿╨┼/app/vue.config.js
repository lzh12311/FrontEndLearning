module.exports = {
  lintOnSave: false
}