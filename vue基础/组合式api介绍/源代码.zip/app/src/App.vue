<template>
  <div>
    <div>
      <p>用户: {{ userInfo.userName }}</p>
      <p>联系方式: {{ userInfo.userMobile }}</p>
    </div>
    <div class="container">
      <div class="flex">
        <p>总重量：{{ countWeight }}（吨）</p>
        <a @click="add" href="javascript:;">新增</a>
      </div>
      <div class="group" v-for="(item, index) in orderList" :key="index">
        <div class="flex">
          <p>货物名称：{{ item.name }}</p>
          <p>重量：{{ item.weight }}（吨）</p>
        </div>
        <div class="flex">
          <p>起点：{{ item.startPoint }}</p>
          <p>终点：{{ item.terminalPoint }}</p>
        </div>
        <div class="flex">
          <p>体积：{{ item.startPoint }}（立方米）</p>
          <p>订单状态：已完结</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {
      userInfo: {
        userName: "张三",
        userMobile: 13797053405,
      },
      orderList: [
        {
          name: "干果",
          startPoint: "北京",
          terminalPoint: "上海",
          weight: 2,
          volume: 800,
        },
        {
          name: "干果",
          startPoint: "北京",
          terminalPoint: "上海",
          weight: 2,
          volume: 800,
        },
      ],
    };
  },
  methods: {
    add() {
      const data = {
        name: "干果",
        startPoint: "北京",
        terminalPoint: "上海",
        weight: 2,
        volume: 800,
      };
      this.orderList.push(data);
    },
  },
  computed: {
    countWeight() {
      return this.orderList.reduce((total, cur) => total + cur.weight, 0);
    },
  },
};
</script>

<style scoped>
.container {
  padding: 10px 20px;
  width: 400px;
  background-color: #f5f5f5;
}
.container .group {
  padding: 10px;
  margin-bottom: 10px;
  background-color: #3e73ca;
  border-radius: 5px;
  color: #fff;
}
.flex {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.flex a {
  text-decoration: none;
}
</style>
