<template>
    <div>{{foo}}</div>
</template>
<script>
 export default {
    data() {
        return {
            foo: '我是一个组件'
        }
    }
 }
</script>