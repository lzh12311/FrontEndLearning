import { createApp } from 'vue'
import App from './setUp.vue'

createApp(App).mount('#app')
