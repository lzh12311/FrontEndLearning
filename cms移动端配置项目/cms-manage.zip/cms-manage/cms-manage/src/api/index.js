import { nodeUrl } from '@/config'
// 上传图片
export const upLoadUrl = `${nodeUrl}/file/upload`