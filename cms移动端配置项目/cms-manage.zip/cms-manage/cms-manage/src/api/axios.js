import fetch from '@/utils/request'
export default fetch
