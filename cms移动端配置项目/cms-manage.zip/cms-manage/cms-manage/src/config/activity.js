// 活动页状态
const activityStatus = [
  { label: '上线', value: 1 },
  { label: '下线', value: 0 }
]

export { activityStatus }
