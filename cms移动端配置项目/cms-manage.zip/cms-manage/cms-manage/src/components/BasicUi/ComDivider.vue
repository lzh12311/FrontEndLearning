<template functional>
  <div class="com-divider" />
</template>

<style lang="less" scoped>
// 组件编辑-分割线
.com-divider {
  height: 1px;
  padding: 12px 16px;
  background-color: rgb(235, 237, 240);
  background-clip: content-box;
  box-sizing: content-box;
}
</style>
