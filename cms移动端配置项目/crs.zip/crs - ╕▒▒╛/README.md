###### cms管理系统传给h5的数据格式

**pageChange事件**

```
{
  id: '',
  name: '页面标题',
  desc: '',
  backgroundColor: '',
  backgroundImage: '',
  backgroundPosition: 'top',
  cover: '',
  componentList: []
}
```

**setPreview事件**
index

**setActive事件**
index

###### h5传给cms的数据格式

**setActive**
index

**pageChange**

```
{
  id: '',
  name: '页面标题',
  desc: '',
  backgroundColor: '',
  backgroundImage: '',
  backgroundPosition: 'top',
  cover: '',
  componentList: []
}
```

**pageHeightChange**
```
{
  height: '',
  componentsTopList: []
}
```
