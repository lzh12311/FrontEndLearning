数据结构属性说明

```
const property = {
  /** 容器上下padding */
  columnPadding: 4,
  /** 容器左右padding */
  rowPadding: 24,
  textColor: '#4e4e4e',
  backgroundColor: '#000000',
  /** 图片圆角 */
  borderRadius: 0,
  /** 单行还是多行 */
  isMultiline: 1,
  lineNumber: 4,
  isScroll: true,
  imageList: []
}
```