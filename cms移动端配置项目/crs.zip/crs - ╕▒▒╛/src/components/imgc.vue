<template>
  <van-image
    width="100"
    height="100"
    src="https://img01.yzcdn.cn/vant/cat.jpeg"
  />
</template>

<script>
export default {
  name: 'Image'
}
</script>

<style scoped>

</style>
