<template>
  <div class="view">
    <HelloWorld />
    <p>我是home页面</p>
  </div>
</template>
<script>
import HelloWorld from '../../components/HelloWorld'
export default {
  components: {
    HelloWorld
  }
}
</script>
