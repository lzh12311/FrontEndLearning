module.exports = {
  nodeUrl: 'http://127.0.0.1:3300/atlas-cms'
}
