module.exports = {
  baseURL: 'http://erp-newdev.fuchuang-auto.com',
  db: {
    database: 'cms',
    host: '124.223.69.156',
    port: 3306,
    username: 'cms',
    password: 'eTE8JsSJi56RjRtH',
    dialect: 'mysql'
  },
  redis_db: {
    host: '127.0.0.1',
    password: null,
    port:6379
  }
}
