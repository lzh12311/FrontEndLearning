const controller = require('./controller')
const service = require('./service')

module.exports = {
  controller,
  service
}
