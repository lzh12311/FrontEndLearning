
const orderServer = require('./order')

module.exports = {
  orderServer
}
