[TOC]

# 组件分类
## 图文组件
### 单列图片
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224154108915.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 双列图
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224154520614.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 轮播图
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224154520614.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 横向滑动
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224154726696.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 图文导航
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224154856883.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 文本
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224154957137.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 辅助线
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224155100246.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 浮标
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224155645841.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 橱窗位
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224155744326.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

### 弹窗
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224155839835.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

## 营销组件
待定...

# 样式风格
CMS界面风格（有赞）
[有赞网址](https://www.youzan.com/v4/deco/decorate#/create/1)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20210223093148829.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

CMS界面风格（兑吧）
[兑吧网址](https://hd.dlp.duiba.com.cn/static/index/new?appId=81752#/creditShop/creditShopSub/generalSituation)
![在这里插入图片描述](https://img-blog.csdnimg.cn/2021022416055427.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)

![在这里插入图片描述](https://img-blog.csdnimg.cn/20210224161634610.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxNjE2NTkyOTU4,size_16,color_FFFFFF,t_70)